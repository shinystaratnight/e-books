//
//  EncryptingOutputStreamTests.h
//  EncryptingOutputStreamTests
//
//  Created by Jim Dovey on 12-06-03.
//  Copyright (c) 2012 Apress. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface EncryptingOutputStreamTests : SenTestCase <NSStreamDelegate>

@end
