//
//  EmailAddress.m
//  Core Data Contacts
//
//  Created by Jim Dovey on 2012-07-16.
//  Copyright (c) 2012 Apress Inc. All rights reserved.
//

#import "EmailAddress.h"
#import "Person.h"


@implementation EmailAddress

@dynamic email;
@dynamic person;

@end
