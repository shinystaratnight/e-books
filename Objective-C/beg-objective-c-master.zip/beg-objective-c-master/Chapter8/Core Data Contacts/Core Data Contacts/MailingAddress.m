//
//  MailingAddress.m
//  Core Data Contacts
//
//  Created by Jim Dovey on 2012-07-16.
//  Copyright (c) 2012 Apress Inc. All rights reserved.
//

#import "MailingAddress.h"
#import "Person.h"


@implementation MailingAddress

@dynamic city;
@dynamic country;
@dynamic postalCode;
@dynamic region;
@dynamic street;
@dynamic person;

@end
