//
//  ALTAppDelegate.m
//  AutoLayoutTestbed
//
//  Created by Jim Dovey on 12-07-08.
//  Copyright (c) 2012 Apress Inc. All rights reserved.
//

#import "ALTAppDelegate.h"

@implementation ALTAppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end
