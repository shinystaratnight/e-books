# Android for Programmers, 3e
Code Downloads for Android for Programmers

These examples are provided AS IS. All examples are copyright Pearson Education, Inc. and are for your own personal use. 

If you have questions, please contact us via the contact form at https://deitel.com/contact-us.

For our most recent books, see https://deitel.com/books.

**NOTE: Android had breaking changes after we published our book and Google updates the Android Studio development tools frequently. You will have various problems using our code and the steps we list in the book. We recommend that you use a book that is up-to-date with the current Android version.**
